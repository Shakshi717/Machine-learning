def input_matrix(name):
    print(f"Enter the number of rows and columns for matrix {name}:")
    rows = int(input("Rows: "))
    cols = int(input("Columns: "))

    matrix = []
    print(f"Enter the elements of matrix {name} row by row:")
    for i in range(rows):
        row = list(map(int, input().split()))
        if len(row) != cols:
            print(f"Error: Each row must have {cols} elements.")
            return None, None
        matrix.append(row)

    return matrix, rows, cols


def print_matrix(matrix):
    for row in matrix:
        print(" ".join(map(str, row)))


def multiply_matrices(A, B):
    m = len(A)
    n = len(A[0])
    p = len(B)
    q = len(B[0])

    if n != p:
        return None, m, q

    result = [[0] * q for _ in range(m)]

    for i in range(m):
        for j in range(q):
            for k in range(n):
                result[i][j] += A[i][k] * B[k][j]

    return result, m, q


def main():
    print("Matrix A:")
    A, rows_A, cols_A = input_matrix("A")

    if A is None:
        return

    print("Matrix B:")
    B, rows_B, cols_B = input_matrix("B")

    if B is None:
        return

    result, result_rows, result_cols = multiply_matrices(A, B)

    if result is None:
        print("Error: Matrices are not multiplicable.")
    else:
        print("Result of Matrix A multiplied by Matrix B:")
        print_matrix(result)


if __name__ == "__main__":
    main()
