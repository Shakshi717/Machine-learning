def input_matrix():
    while True:
        try:
            rows = int(input("Enter the number of rows: "))
            cols = int(input("Enter the number of columns: "))
            if rows <= 0 or cols <= 0:
                print("Number of rows and columns must be positive integers.")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter integer values.")

    matrix = []
    print(f"Enter the elements of the matrix row by row (space-separated):")
    for i in range(rows):
        while True:
            try:
                row = list(map(int, input(f"Row {i + 1}: ").split()))
                if len(row) != cols:
                    print(f"Error: Row must have {cols} elements. Please enter the row again.")
                    continue
                matrix.append(row)
                break
            except ValueError:
                print("Invalid input. Please enter integers only.")

    return matrix


def transpose_matrix(matrix):
    # Transpose the matrix by swapping rows with columns
    return list(zip(*matrix))


def print_matrix(matrix):
    for row in matrix:
        print(" ".join(map(str, row)))


def main():
    print("Input matrix:")
    matrix = input_matrix()

    print("Original Matrix:")
    print_matrix(matrix)

    transposed = transpose_matrix(matrix)

    print("Transposed Matrix:")
    print_matrix(transposed)


if __name__ == "__main__":
    main()
