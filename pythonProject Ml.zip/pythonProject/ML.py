vcount=0;
ccount=0;
str="My name is Shakshi Yadav";

str=str.lower();
for i in range(0,len(str)):
    if str[i]in ("a","e","i","o","u"):
     vcount = vcount + 1;
    elif (str[i]>="a" and str[i]<="z"):
     ccount = ccount + 1;
print(" the total number of stings");
print(vcount);
print(ccount);
