def input_list(prompt):
    while True:
        try:
            user_input = input(prompt)
            int_list = list(map(int, user_input.split()))
            return int_list
        except ValueError:
            print("Invalid input. Please enter integers separated by spaces.")


def count_common_elements(list1, list2):
    set1 = set(list1)
    set2 = set(list2)
    common_elements = set1 & set2
    return len(common_elements), common_elements


def main():
    print("Enter integers for the first list (separated by spaces):")
    list1 = input_list("First list: ")

    print("Enter integers for the second list (separated by spaces):")
    list2 = input_list("Second list: ")

    count, common_elements = count_common_elements(list1, list2)

    print(f"Number of common elements: {count}")
    print(f"Common elements: {common_elements}")


if __name__ == "__main__":
    main()
